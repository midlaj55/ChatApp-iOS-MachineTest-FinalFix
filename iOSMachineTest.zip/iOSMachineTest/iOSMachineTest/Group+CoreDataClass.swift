//
//  File.swift
//  iOSMachineTest
//
//  Created by Mc on 27/03/24.
//

import Foundation
import CoreData

@objc(GroupName)
public class GroupName: NSManagedObject {

}
