//
//  File1.swift
//  iOSMachineTest
//
//  Created by Mc on 27/03/24.
//

import Foundation
import CoreData


extension GroupName {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<GroupName> {
        return NSFetchRequest<GroupName>(entityName: "GroupName")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var bio: String?
//    @NSManaged public var employees: NSSet?
}

extension GroupName : Identifiable {

}
